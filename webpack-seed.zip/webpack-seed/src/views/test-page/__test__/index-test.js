import { expect } from 'chai'

describe('What is the good unit test?', () => {
  it('should render correct value', () => {
    const res = 'good test'
    expect(res).to.equal('good test')
  })
})
