/**
 * 默认样式+默认逻辑
 */
import '@/common/js/base'
import __ from 'utils/dom'

__('.wbs-news-title').html(`
<h4>测试用页面, 支持多目录分模块开发,具体请看<a href="javascript:;">view/news/news-page</a>/</h4><br />
<h4>可以嵌套目录开发, 打包后, 为平级</h4><br />
<h4>页面跳转为<a href="javascript:;">html/news-page.html</a></h4>`)
