/**
 * 默认样式+默认逻辑 common/js/base.js
 */
import '@/common/js/base'
import './demo.css'
