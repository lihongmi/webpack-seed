import __ from 'utils/dom'

__('.wbs-footer_btn').on('click', () => {
  alert('哎呦, 这都能被你发现~~')
})
