import __ from 'utils/dom'

__('.wbs-header_btn').on('click', () => {
  alert('哎呦, 点到我头了~~')
})
