## Component?

Can store common component here.